"""Bounded frozen NF4 host storage. Experimental; deliberately not installed by apply()."""
import copy
import threading
from contextlib import contextmanager
from dataclasses import dataclass


def map_state(state, transform):
    """Clone the QuantState tree without mutating shared original metadata."""
    import torch
    result=copy.copy(state)
    for name,value in vars(state).items():
        if isinstance(value,torch.Tensor):setattr(result,name,transform(name,value))
        elif name=='state2' and value is not None:setattr(result,name,map_state(value,lambda key,t:transform('state2.'+key,t)))
    return result


@dataclass(frozen=True)
class HostNF4:
    packed: object
    state: object
    versions: tuple

    @classmethod
    def capture(cls,packed,state):
        """D2H complete before publication; no GPU tensor survives in handle."""
        tensors=[]
        def host(name,value):
            cpu=value.detach().to('cpu').contiguous().pin_memory()
            tensors.append((cpu,cpu._version));return cpu
        data=host('packed',packed)
        meta=map_state(state,host)
        return cls(data,meta,tuple(tensors))

    def check(self):
        if any(t._version!=version for t,version in self.versions):
            raise RuntimeError('frozen host NF4 bytes modified after capture')


class NF4Slots:
    """Fixed slot count, bounded capacities, ready AND last-reader events.

    No GPU slot/view may be stored in an autograd context. Lock prevents leases
    from overlapping on the host; GPU reuse is ordered by the read_done event.
    """
    def __init__(self,device=0,slots=2,max_elements=8960*1536):
        import torch
        self.device=device;self.count=slots;self.max_elements=max_elements
        self.lock=threading.Lock();self.next=0;self.copy=torch.cuda.Stream(device=device)
        self.slots=[{'buffers':{},'done':None} for _ in range(slots)]

    @contextmanager
    def acquire(self,host):
        import torch
        host.check()
        with self.lock,torch.cuda.device(self.device):
            slot=self.slots[self.next];self.next=(self.next+1)%self.count
            compute=torch.cuda.current_stream(self.device)
            with torch.cuda.stream(self.copy):
                if slot['done'] is not None:self.copy.wait_event(slot['done'])
                def stage(name,value):
                    # Largest packed matrix + nested statistics, explicit hard bound.
                    limit=self.max_elements//2+1 if name=='packed' else self.max_elements//64+1024
                    if value.numel()>limit:raise ValueError('weight exceeds slot capacity')
                    key=(name,value.dtype)
                    existing=slot['buffers'].get(key)
                    if existing is None or existing.numel()<value.numel():
                        # Reallocation cannot free storage with pending readers.
                        # Existing tensors are record_stream protected below.
                        existing=torch.empty(value.numel(),device=self.device,dtype=value.dtype)
                        slot['buffers'][key]=existing
                    view=existing[:value.numel()].view(value.shape)
                    view.copy_(value,non_blocking=True)
                    return view
                data=stage('packed',host.packed)
                state=map_state(host.state,stage)
                ready=self.copy.record_event()
            compute.wait_event(ready)
            data.record_stream(compute)
            map_state(state,lambda _,t:(t.record_stream(compute) or t))
            try:yield data,state
            finally:
                slot['done']=compute.record_event()

    def gpu_bytes(self):
        return sum(t.numel()*t.element_size() for s in self.slots for t in s['buffers'].values())


def streamed_linear(x,host,pool,bias=None):
    """Frozen native bnb FW and original dX BW, with CPU-only autograd state."""
    import torch
    from bitsandbytes.autograd._functions import MatMul4Bit
    import bitsandbytes.functional as F

    class Stream(torch.autograd.Function):
        @staticmethod
        def forward(ctx,a,b):
            ctx.host=host;ctx.pool=pool;ctx.bias_dtype=None if b is None else b.dtype
            ctx.need_bias=b is not None and b.requires_grad
            # Native dispatch is delegated, but its temporary context must NOT
            # retain a packed GPU view through the whole model forward.
            with pool.acquire(host) as (packed,state):
                result=MatMul4Bit.apply(a,packed,None,b,state)
            return result

        @staticmethod
        def backward(ctx,dy):
            db=dy.sum(0,dtype=ctx.bias_dtype) if ctx.need_bias else None
            dx=None
            if ctx.needs_input_grad[0]:
                with ctx.pool.acquire(ctx.host) as (packed,state):
                    dx=torch.matmul(dy,F.dequantize_4bit(packed,state).to(dy.dtype))
            return dx,db
    if x.numel()==0:raise ValueError('empty input requires native fallback before streaming')
    return Stream.apply(x,bias)
