"""T4 capability/gradient/storage probe; never a scored training run."""

import json
import time
from pathlib import Path


def main():
    import torch
    from torch.nn import functional as functional
    from torch.nn.attention import SDPBackend, sdpa_kernel

    class SharedKV(torch.autograd.Function):
        @staticmethod
        def forward(ctx, q, k, v, mask, scaling):
            # Native SDPA sees head-expanded leaf views of one physical K/V head.
            # Its per-head gradients are reduced explicitly in FP32 in backward.
            with torch.enable_grad(), torch.autocast("cuda", enabled=False):
                qleaf = q.to(torch.float16).detach().requires_grad_(True)
                kleaf = k.to(torch.float16).expand(-1, q.shape[1], -1, -1)
                vleaf = v.to(torch.float16).expand(-1, q.shape[1], -1, -1)
                kleaf = kleaf.detach().requires_grad_(True)
                vleaf = vleaf.detach().requires_grad_(True)
                with sdpa_kernel(SDPBackend.EFFICIENT_ATTENTION):
                    output = functional.scaled_dot_product_attention(
                        qleaf, kleaf, vleaf, attn_mask=mask, scale=scaling, dropout_p=0.0,
                    )
            ctx.save_for_backward(qleaf, kleaf, vleaf)
            ctx.inner_output = output
            ctx.input_dtypes = (q.dtype, k.dtype, v.dtype)
            return output.detach()

        @staticmethod
        def backward(ctx, incoming):
            gradients = torch.autograd.grad(ctx.inner_output, ctx.saved_tensors, incoming)
            qgrad = gradients[0].to(ctx.input_dtypes[0])
            kgrad = gradients[1].float().sum(1, keepdim=True).to(ctx.input_dtypes[1])
            vgrad = gradients[2].float().sum(1, keepdim=True).to(ctx.input_dtypes[2])
            return qgrad, kgrad, vgrad, None, None

    def reference(q, k, v, mask):
        kr = k[:, :, None].expand(-1, -1, 6, -1, -1).reshape(4, 12, 512, 128)
        vr = v[:, :, None].expand(-1, -1, 6, -1, -1).reshape(4, 12, 512, 128)
        with sdpa_kernel(SDPBackend.EFFICIENT_ATTENTION), torch.autocast("cuda"):
            return functional.scaled_dot_product_attention(q, kr, vr, attn_mask=mask)

    def native_gqa(q, k, v, mask):
        with sdpa_kernel(SDPBackend.EFFICIENT_ATTENTION), torch.autocast("cuda"):
            return functional.scaled_dot_product_attention(q, k, v, attn_mask=mask,
                                                           enable_gqa=True)

    def shared(q, k, v, mask):
        return torch.cat([SharedKV.apply(q[:, h*6:(h+1)*6], k[:, h:h+1], v[:, h:h+1],
                                        mask, 128**-0.5) for h in range(2)], dim=1)

    torch.manual_seed(123)
    tensors = [torch.randn(4, h, 512, 128, device="cuda") for h in (12, 2, 2)]
    positions = torch.arange(512, device="cuda")
    lengths = torch.tensor([512, 300, 200, 128], device="cuda")
    mask = ((positions[None, :] <= positions[:, None])[None, None]
            & (positions[None, None, None, :] < lengths[:, None, None, None]))
    incoming = torch.randn_like(tensors[0], dtype=torch.float16) * 0.01
    report = {"diagnostic_only": True, "gpu": torch.cuda.get_device_name(0), "cases": []}
    baseline = None
    for name, function in (("repeat_kv_reference", reference),
                           ("native_gqa_forced_efficient", native_gqa),
                           ("stride_zero_shared_kv_fp32_reduce", shared)):
        values = [x.detach().clone().requires_grad_() for x in tensors]
        torch.cuda.synchronize()
        torch.cuda.reset_peak_memory_stats()
        before = torch.cuda.memory_allocated()
        started = time.perf_counter()
        try:
            with torch.profiler.profile(activities=[torch.profiler.ProfilerActivity.CPU,
                                                    torch.profiler.ProfilerActivity.CUDA]) as prof:
                output = function(*values, mask)
                torch.cuda.synchronize()
                live = torch.cuda.memory_allocated() - before
                gradients = torch.autograd.grad(output, values, incoming)
                torch.cuda.synchronize()
            current = (output.detach(), tuple(g.detach() for g in gradients))
            if baseline is None:
                baseline = current
            row = {"name": name, "ok": True, "forward_live_bytes": live,
                   "peak_extra_bytes": torch.cuda.max_memory_allocated() - before,
                   "diagnostic_wall_s": time.perf_counter() - started,
                   "output_max_abs": (current[0]-baseline[0]).abs().max().item(),
                   "gradient_max_abs": [(a-b).abs().max().item()
                                        for a,b in zip(current[1],baseline[1],strict=True)],
                   "gradient_finite": [bool(torch.isfinite(g).all()) for g in gradients],
                   "events": [e.key for e in prof.key_averages() if any(
                       needle in e.key.lower() for needle in
                       ("attention", "clone", "contiguous", "repeat", "copy"))]}
            del output, gradients
        except RuntimeError as error:
            row = {"name": name, "ok": False, "error": str(error)}
        report["cases"].append(row)
        del values
    Path("gqa_probe.json").write_text(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
