"""Offload only quantized saved-activation packets to pinned host memory.

Transfers use stream ordering and an event for cross-stream consumers. The live
forward tensors, attention's 4D tensors and model weights remain untouched.
"""

import weakref


class _Offloaded:
    __slots__ = ("packet", "device", "event", "__weakref__")

    def __init__(self, packet, device, event):
        self.packet, self.device, self.event = packet, device, event


def offload_packed_hooks(pack, unpack, *, min_bytes=262144, should_offload=None):
    import torch

    from .activation_storage import _Packet

    wrappers = {}

    def offload(tensor):
        packet = pack(tensor)
        if not isinstance(packet, _Packet):
            return packet
        cached = wrappers.get(id(packet))
        previous = cached() if cached is not None else None
        if previous is not None:
            return previous
        if (packet.packed.numel() * packet.packed.element_size() < min_bytes
                or should_offload is not None and not should_offload()):
            # A packet may be reused across a layer boundary. Keep the first
            # residency decision; never mutate a packet already saved raw.
            wrappers[id(packet)] = weakref.ref(packet)
            return packet
        device = packet.packed.device
        with torch.cuda.device(device):
            stream = torch.cuda.current_stream(device)
            host_packed = torch.empty_like(packet.packed, device="cpu", pin_memory=True)
            host_scales = torch.empty_like(packet.scales, device="cpu", pin_memory=True)
            host_packed.copy_(packet.packed, non_blocking=True)
            host_scales.copy_(packet.scales, non_blocking=True)
            packet.packed.record_stream(stream)
            packet.scales.record_stream(stream)
            ready = torch.cuda.Event()
            ready.record(stream)
        packet.packed, packet.scales = host_packed, host_scales
        result = _Offloaded(packet, device, ready)
        wrappers[id(packet)] = weakref.ref(result)
        return result

    def restore(value):
        if not isinstance(value, _Offloaded):
            return unpack(value)
        packet = value.packet
        cached = packet.decoded() if packet.decoded is not None else None
        if cached is not None:
            # The base reader also checks the original tensor's version.
            return unpack(packet)
        host_packed, host_scales = packet.packed, packet.scales
        with torch.cuda.device(value.device):
            torch.cuda.current_stream(value.device).wait_event(value.event)
            packet.packed = host_packed.to(value.device, non_blocking=True)
            packet.scales = host_scales.to(value.device, non_blocking=True)
            try:
                return unpack(packet)
            finally:
                # Do not retain GPU compressed buffers between backward nodes.
                packet.packed, packet.scales = host_packed, host_scales

    return offload, restore
