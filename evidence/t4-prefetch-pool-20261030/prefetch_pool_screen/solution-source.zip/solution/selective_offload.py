"""Keep later decoder layers resident and offload early compressed packets.

The existing ordered pinned transfer is unchanged. Earlier layers are consumed
last by backward, so their storage can leave the GPU for most of the step.
The count is an implementation choice, independent of training/data settings.
"""

from contextvars import ContextVar
from functools import wraps

_layer_index = ContextVar("setww_offload_layer", default=None)
_offload_layers = 16


def selective_packed_hooks(pack, unpack):
    from .pipelined_pool import pooled_offload_hooks

    def selected():
        index = _layer_index.get()
        return index is not None and 0 <= index < _offload_layers

    return pooled_offload_hooks(pack, unpack, should_offload=selected)


def patch_selective_offload(layers=16):
    from transformers.models.qwen2.modeling_qwen2 import Qwen2DecoderLayer

    if isinstance(layers, bool) or not isinstance(layers, int) or not 0 <= layers <= 28:
        raise ValueError("offloaded decoder layers must be between 0 and 28")
    global _offload_layers
    _offload_layers = layers
    original = Qwen2DecoderLayer.forward
    if getattr(original, "_setww_selective_offload", False):
        return True

    @wraps(original)
    def forward(self, *args, **kwargs):
        index = getattr(self.self_attn, "layer_idx", None)
        token = _layer_index.set(index)
        try:
            return original(self, *args, **kwargs)
        finally:
            _layer_index.reset(token)

    forward._setww_selective_offload = True
    Qwen2DecoderLayer.forward = forward
    return True
