"""Decode saved gate/up inside starter-derived backward instead of two full buffers.

The unchanged starter forward is used. Its rewritten backward is explicitly
excluded from author quota. Quantization bytes and FP16 reconstruction match the
existing INT4/64 codec. Offloaded/noneligible packets use the existing reader.
"""

from functools import lru_cache, wraps


@lru_cache(maxsize=1)
def _autograd():
    import torch
    from torch.autograd.function import once_differentiable

    class _PackedSwiGLU(torch.autograd.Function):
        @staticmethod
        def forward(ctx, gate, up, gate_packet, up_packet):
            from .swiglu import BLOCK, example_swiglu_fwd_kernel

            output = torch.empty_like(gate)
            with torch.cuda.device(gate.device):
                example_swiglu_fwd_kernel[((gate.numel()+BLOCK-1)//BLOCK,)](
                    gate, up, output, gate.numel(), BLOCK=BLOCK,
                )
            ctx.save_for_backward(gate_packet.packed, gate_packet.scales,
                                  up_packet.packed, up_packet.scales)
            ctx.originals = [(p.original, p.version) for p in (gate_packet, up_packet)]
            ctx.packets = (gate_packet, up_packet)  # Keep identity dedup until backward.
            ctx.shape, ctx.elements = gate.shape, gate.numel()
            return output

        @staticmethod
        @once_differentiable
        def backward(ctx, incoming):
            from ._packed_swiglu_kernels import example_swiglu_packed_bwd_kernel

            for reference, version in ctx.originals:
                original = reference()
                if original is not None and original._version != version:
                    raise RuntimeError("a packed saved activation was modified in-place")
            gate_bytes, gate_scale, up_bytes, up_scale = ctx.saved_tensors
            incoming = incoming.to(torch.float16).contiguous()
            gate_grad = torch.empty(ctx.shape, device=incoming.device, dtype=torch.float16)
            up_grad = torch.empty_like(gate_grad)
            with torch.cuda.device(incoming.device):
                example_swiglu_packed_bwd_kernel[((ctx.elements+1023)//1024,)](
                    incoming, gate_bytes, gate_scale, up_bytes, up_scale,
                    gate_grad, up_grad, ctx.elements, block=1024, num_warps=4,
                )
            ctx.packets = None
            return gate_grad, up_grad, None, None

    return _PackedSwiGLU


def patch_packed_swiglu():
    import torch

    from . import swiglu as helper
    from .activation_storage import _active_codec_hooks, _Packet

    original = helper.swiglu
    if getattr(original, "_setww_packed_swiglu", False):
        return True

    @wraps(original)
    def forward(gate, up):
        hooks = _active_codec_hooks.get()
        supported = (hooks is not None and torch.is_grad_enabled() and gate.is_cuda
                     and up.device == gate.device and gate.shape == up.shape
                     and gate.dtype == up.dtype == torch.float16
                     and gate.shape[-1] == 8960 and gate.is_contiguous() and up.is_contiguous()
                     and gate.requires_grad and up.requires_grad and gate.numel() >= 262144)
        if not supported:
            return original(gate, up)
        gate_packet, up_packet = hooks[0](gate), hooks[0](up)
        if not all(isinstance(p, _Packet) and p.bits == 4 and p.block == 64
                   and p.packed.is_cuda for p in (gate_packet, up_packet)):
            return original(gate, up)
        return _autograd().apply(gate, up, gate_packet, up_packet)

    forward._setww_packed_swiglu = True
    helper.swiglu = forward
    return True
