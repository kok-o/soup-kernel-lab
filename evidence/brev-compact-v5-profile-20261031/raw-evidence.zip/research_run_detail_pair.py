"""Run detailed profiles serially, within the Brev GPU lock."""

import json
import os
import subprocess
import sys
from pathlib import Path


def main():
    lab = Path("/home/ubuntu/workspace/soup-lab")
    for name in ("v5-control-cold", "compact-decoder-85fd6fa"):
        repo = lab / name
        sys.path.insert(0, str(repo / "harness"))
        import run_task

        out = repo / "runs_detailed_profile"
        out.mkdir(exist_ok=True)
        config = run_task.make_config(out, lab / "reserve-v5/data/train.jsonl", 1)
        command = [sys.executable, str(repo / "research/research_detailed_profile.py"),
            "--solution", "--config", str(config), "--metrics", str(out / "metrics.json"),
            "--profile", str(out / "kernels.json")]
        env = dict(run_task.OFFLINE_ENV, PYTHONPATH=str(repo),
            TRITON_CACHE_DIR=str(out / "triton_cache"),
            TORCHINDUCTOR_CACHE_DIR=str(out / "inductor_cache"),
            SOUP_DB_PATH=str(out / "experiments.db"),
            SETWW_SPEED_PROFILE_REPORT=str(out / "lifecycle.json"),
            SETWW_DETAILED_REPORT=str(out / "cpu-shapes.json"))
        print(json.dumps({"profile_begin": name}), flush=True)
        with (out / "diagnostic.log").open("w") as log:
            result = subprocess.run(command, cwd=repo, env=env, stdout=log,
                                    stderr=subprocess.STDOUT, check=False)
        print(json.dumps({"profile_end": name, "exit_code": result.returncode}), flush=True)
        if result.returncode:
            raise SystemExit(result.returncode)
        # common/run_task keep the same immutable task across both repositories.
        sys.path.pop(0)


if __name__ == "__main__":
    main()
