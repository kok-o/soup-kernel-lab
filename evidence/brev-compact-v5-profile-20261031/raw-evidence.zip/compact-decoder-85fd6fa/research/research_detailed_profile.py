"""Unscored profiling wrapper; official harness/task files remain unchanged."""

import json
import os
from collections import Counter
from functools import wraps
from pathlib import Path


def main():
    import torch

    import solution
    import research_speed_profile

    shapes = Counter()
    layouts = Counter()
    profiles = []
    original_profile = torch.profiler.profile

    def profile(*args, **kwargs):
        kwargs["record_shapes"] = True
        result = original_profile(*args, **kwargs)
        profiles.append(result)
        return result

    torch.profiler.profile = profile
    original_apply = solution.apply

    def annotate(function, label, argument=0):
        @wraps(function)
        def observed(*args, **kwargs):
            value = args[argument] if argument < len(args) else None
            shape = tuple(value.shape) if isinstance(value, torch.Tensor) else ()
            shapes[(label, shape)] += 1
            with torch.profiler.record_function("setww."+label):
                return function(*args, **kwargs)
        return observed

    def traced_apply():
        original_apply()
        import bitsandbytes as bnb
        from bitsandbytes.autograd._functions import MatMul4Bit
        from transformers.models.qwen2 import modeling_qwen2 as qwen

        from solution import activation_storage, forward_head, packed_swiglu, varlen_gqa

        bnb.nn.Linear4bit.forward = annotate(bnb.nn.Linear4bit.forward, "nf4.forward", 1)
        MatMul4Bit.backward = staticmethod(annotate(MatMul4Bit.backward, "nf4.dX", 1))
        activation_storage.pack_activation = annotate(activation_storage.pack_activation,
                                                      "codec.pack")
        activation_storage.unpack_activation = annotate(activation_storage.unpack_activation,
                                                        "codec.unpack")
        for module, name in ((forward_head, "head"), (packed_swiglu, "swiglu"),
                             (varlen_gqa, "attention")):
            function = module._autograd()
            for operation in ("forward", "backward"):
                original = getattr(function, operation)
                setattr(function, operation, staticmethod(annotate(
                    original, name+"."+operation, 1)))

        linear = torch.nn.functional.linear

        @wraps(linear)
        def observed_linear(source, weight, bias=None):
            if weight.shape[0] > 100000:
                shapes[("head.linear.forward", tuple(source.shape))] += 1
                with torch.profiler.record_function("setww.head.linear.forward"):
                    return linear(source, weight, bias)
            return linear(source, weight, bias)

        torch.nn.functional.linear = observed_linear
        gradient = torch.autograd.grad
        torch.autograd.grad = annotate(gradient, "autograd.grad")
        original_layer = qwen.Qwen2DecoderLayer.forward

        @wraps(original_layer)
        def layer(self, *args, **kwargs):
            result = original_layer(self, *args, **kwargs)
            layouts[(self.self_attn.layer_idx, tuple(result.shape))] += 1
            return result

        qwen.Qwen2DecoderLayer.forward = layer

    solution.apply = traced_apply
    try:
        research_speed_profile.main()
    finally:
        rows = []
        if profiles:
            for event in profiles[-1].key_averages(group_by_input_shape=True):
                if event.device_type == torch.autograd.DeviceType.CUDA:
                    continue
                rows.append({"name": event.key, "shapes": event.input_shapes,
                    "count": event.count, "cpu_total_us": event.cpu_time_total,
                    "cpu_self_us": event.self_cpu_time_total,
                    "device_total_us": getattr(event, "device_time_total", 0),
                    "device_self_us": getattr(event, "self_device_time_total", 0)})
        rows.sort(key=lambda row: -row["cpu_self_us"])
        report = {"diagnostic_only": True,
            "scope": "CPU/GPU profiler on 16 active training steps; not scored wall time",
            "shape_counts_scope": "all 26 steps including warmup",
            "calls_and_shapes": [{"name": key[0], "shape": key[1], "count": count}
                                 for key, count in sorted(shapes.items())],
            "decoder_output_shapes": [{"layer": key[0], "shape": key[1], "count": count}
                                      for key, count in sorted(layouts.items())],
            "cpu_events": rows}
        Path(os.environ["SETWW_DETAILED_REPORT"]).write_text(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
