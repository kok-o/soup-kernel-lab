"""Diagnostic of compact decoder differences; never part of the scored runtime."""

import json
import os
from pathlib import Path

import torch

import solution
from solution import compact_decoder
from solution.test_compact_decoder import _model


def error(actual, expected):
    difference = actual.float()-expected.float()
    return {"max_abs": difference.abs().max().item(),
            "relative_l2": (difference.norm()/expected.float().norm().clamp_min(1e-30)).item(),
            "equal_fraction": (actual == expected).float().mean().item()}


solution.apply()
if os.environ.get("SETWW_LOSSLESS_DIAGNOSTIC") == "1":
    from solution import activation_storage

    activation_storage.saved_activation_hooks = lambda **_kwargs: (lambda x: x, lambda x: x)
torch.manual_seed(843)
model = _model()
with torch.no_grad():
    for name, parameter in model.named_parameters():
        if "lora_B" in name:
            parameter.normal_(0, 0.002)
parameters = [(name, parameter) for name, parameter in model.named_parameters()
              if parameter.requires_grad]
initial = [parameter.detach().clone() for _, parameter in parameters]
tokens = torch.randint(1, 103, (4, 193), device="cuda")
lengths = torch.tensor([193, 140, 100, 40], device="cuda")
valid = torch.arange(193, device="cuda")[None] < lengths[:, None]
labels = tokens.masked_fill(~valid, -100)
labels[:, :5] = -100
state = torch.cuda.get_rng_state()
observations = {}


def observe(name):
    def hook(_module, _arguments, output):
        if hasattr(output, "last_hidden_state"):
            output = output.last_hidden_state
        elif isinstance(output, tuple):
            output = output[0]
        output = output.detach()
        if tuple(output.shape[:2]) == (4, 193):
            output = output[valid]
        elif output.ndim == 3 and output.shape[0] == 1:
            output = output.squeeze(0)
        observations[name] = output.float().clone()
    return hook


for name, module in model.named_modules():
    if any(name.endswith(suffix) for suffix in (
        "input_layernorm", "post_attention_layernorm", "q_proj", "k_proj", "v_proj",
        "o_proj", "gate_proj", "up_proj", "down_proj", "self_attn", "mlp", "layers.0",
        "layers.1", "model.norm", "base_layer", "lora_A.default", "lora_B.default",
        "lora_dropout.default")):
        module.register_forward_hook(observe(name))


def execute(enabled):
    compact_decoder._enabled = enabled
    model.zero_grad(set_to_none=True)
    with torch.no_grad():
        for (_, parameter), start in zip(parameters, initial, strict=True):
            parameter.copy_(start)
    optimizer = torch.optim.AdamW([p for _, p in parameters], lr=2e-4)
    scaler = torch.amp.GradScaler("cuda", init_scale=65536.0)
    torch.cuda.set_rng_state(state)
    observations.clear()
    with torch.autocast("cuda", dtype=torch.float16):
        output = model(input_ids=tokens, attention_mask=valid, labels=labels, use_cache=False)
    scaler.scale(output.loss).backward()
    scaler.unscale_(optimizer)
    gradients = {name: parameter.grad.detach().clone() for name, parameter in parameters}
    torch.nn.utils.clip_grad_norm_([p for _, p in parameters], 1.0)
    scaler.step(optimizer)
    scaler.update()
    updates = {name: parameter.detach()-start
               for (name, parameter), start in zip(parameters, initial, strict=True)}
    return {"loss": output.loss.item(), "gradients": gradients, "updates": updates,
            "rng": torch.cuda.get_rng_state(), "observations": dict(observations)}


reference = execute(False)
candidate = execute(True)
report = {"diagnostic_only": True, "reference_loss": reference["loss"],
          "candidate_loss": candidate["loss"],
          "rng_equal": torch.equal(reference["rng"], candidate["rng"])}
for category in ("observations", "gradients", "updates"):
    report[category] = {name: error(value, reference[category][name])
                        for name, value in candidate[category].items()}
Path(os.environ["SETWW_CORRECTNESS_REPORT"]).write_text(json.dumps(report, indent=2))
print(json.dumps(report, indent=2), flush=True)
