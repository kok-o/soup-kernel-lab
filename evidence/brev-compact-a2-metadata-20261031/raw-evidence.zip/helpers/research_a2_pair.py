"""Serial A/B/B/A native-cast/metadata incremental cold train screens."""

import json
import os
import subprocess
import sys
from pathlib import Path

lab = Path(__file__).absolute().parent
cases = {
    "A": ("compact-dropout", "35ea24c796a35a93e8beca5943675fc4fae70d16",
          "3172cf8b138a331262bb63a471a31f67e2936336bb78ca13fc5192ade6a46ce5"),
    "B": ("compact-a2-metadata-v2", "a9ac67ea6c17e61127613e976d39a096a298058d",
          "53d2057ac60abda2d7ec00a441c91d5b20bb9551973a874582cb1e12e98e338d"),
}
rows = []
for label in ("A0", "B1", "B2", "A3"):
    name, commit, digest = cases[label[0]]
    repo = lab / name
    subprocess.run([sys.executable, str(repo / "research_train_a2_once.py"), label],
        cwd=repo, env=dict(os.environ, SETWW_PAIR_EXPECTED_SHA=digest,
                          SETWW_PAIR_COMMIT=commit), check=True)
    row = json.loads((repo / "runs_a2_incremental" / (label+".json")).read_text())
    rows.append({"label": label, "repository": name, **row})
(lab / "a2-incremental-pair.json").write_text(json.dumps({
    "paired_cold_train_only": True, "official_qualification": False,
    "order": [row["label"] for row in rows], "runs": rows}, indent=2))
print("A2 paired cold train screens completed", flush=True)
