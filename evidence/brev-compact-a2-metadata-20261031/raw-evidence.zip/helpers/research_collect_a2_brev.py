"""Collect original A2 full screen and paired cold train proofs, with source snapshots."""

import hashlib
import io
import json
import zipfile
from pathlib import Path

lab = Path("/home/ubuntu/workspace/soup-lab")
members = {}
sources = {}
for directory, commit, expected in (
    ("compact-dropout", "35ea24c796a35a93e8beca5943675fc4fae70d16",
     "3172cf8b138a331262bb63a471a31f67e2936336bb78ca13fc5192ade6a46ce5"),
    ("compact-a2-metadata-v2", "a9ac67ea6c17e61127613e976d39a096a298058d",
     "53d2057ac60abda2d7ec00a441c91d5b20bb9551973a874582cb1e12e98e338d"),
):
    repo = lab / directory
    digest = hashlib.sha256()
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as archive:
        for path in sorted((repo / "solution").glob("*.py")):
            data = path.read_bytes()
            digest.update(path.name.encode())
            digest.update(data)
            archive.writestr("solution/" + path.name, data)
    assert digest.hexdigest() == expected
    members["sources/" + directory + ".zip"] = buffer.getvalue()
    sources[directory] = {"commit": commit, "solution_sha256": expected,
                          "snapshot": "post-run; pair records also check before and after"}

pair = json.loads((lab / "a2-incremental-pair.json").read_bytes())
members["paired/original-pair.json"] = (lab / "a2-incremental-pair.json").read_bytes()
for run in pair["runs"]:
    repo = lab / run["repository"]
    source = sources[run["repository"]]
    assert run["code_commit"] == source["commit"]
    assert run["solution_sha256_before"] == run["solution_sha256_after"] == source["solution_sha256"]
    label = run["label"]
    members["paired/" + label + ".json"] = (repo / "runs_a2_incremental" / (label + ".json")).read_bytes()
    for name in ("train.log", "metrics.json", "task.yaml"):
        members["paired/" + label + "/" + name] = (
            repo / "runs_a2_incremental" / label / name).read_bytes()

repo = lab / "compact-a2-metadata-v2"
screen = repo / "runs_integration_screen"
for name in ("result.json", "solution_1/train.log", "solution_1/metrics.json",
             "solution_1/task.yaml", "eval_solution.json", "eval_solution.log"):
    members["first-screen/" + name] = (screen / name).read_bytes()
for name in ("full-tests.log", "integration-screen.log"):
    members["first-screen/" + name] = (repo / name).read_bytes()
assert b"348 passed" in members["first-screen/full-tests.log"]
members["initial-metadata-fixture-failure.log"] = (
    lab / "compact-a2-metadata/full-tests.log").read_bytes()
assert b"1 failed" in members["initial-metadata-fixture-failure.log"]
for name in ("research_train_a2_once.py", "research_a2_pair.py", Path(__file__).name):
    path = lab / name
    if not path.exists():
        path = repo / name
    members["helpers/" + name] = path.read_bytes()
summary = {"platform": "Brev Tesla T4, not Kaggle qualification", "sources": sources,
    "first_screen": json.loads(members["first-screen/result.json"])["summary"],
    "paired_order": pair["order"], "paired_train_only": True,
    "paired": [{"label": run["label"], "source": run["repository"],
                "wall_s": run["result"]["wall_s"], "peak_mib": run["result"]["gpu_peak_mib"]}
               for run in pair["runs"]]}
members["SUMMARY.json"] = json.dumps(summary, indent=2).encode()
manifest = {name: hashlib.sha256(data).hexdigest() for name, data in sorted(members.items())}
members["EVIDENCE_MANIFEST.json"] = json.dumps(manifest, indent=2).encode()
destination = lab / "a2-brev-cold-evidence.zip"
with zipfile.ZipFile(destination, "w", zipfile.ZIP_DEFLATED) as archive:
    for name, data in sorted(members.items()):
        archive.writestr(name, data)
print(json.dumps({"archive": str(destination), "sha256": hashlib.sha256(
    destination.read_bytes()).hexdigest(), "summary": summary}, indent=2), flush=True)
