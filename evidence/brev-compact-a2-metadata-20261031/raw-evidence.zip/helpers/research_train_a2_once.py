"""Cold train screen through unchanged harness; source is checked before and after."""

import hashlib
import json
import os
import sys
from pathlib import Path
from types import SimpleNamespace

repo = Path(__file__).absolute().parent
sys.path.insert(0, str(repo / "harness"))
from run_task import train, write_json


def solution_digest():
    digest = hashlib.sha256()
    for path in sorted((repo / "solution").glob("*.py")):
        digest.update(path.name.encode())
        digest.update(path.read_bytes())
    return digest.hexdigest()


before = solution_digest()
assert before == os.environ["SETWW_PAIR_EXPECTED_SHA"]
args = SimpleNamespace(out=repo / "runs_a2_incremental", seed=1, timeout=1200,
    train_file=repo / "data/train.jsonl")
args.out.mkdir(exist_ok=True)
result = train("solution", sys.argv[1], args)
assert solution_digest() == before
report = {"paired_cold_train_only": True, "official_qualification": False,
    "solution_sha256_before": before, "solution_sha256_after": solution_digest(),
    "code_commit": os.environ["SETWW_PAIR_COMMIT"], "result": result}
destination = args.out / (sys.argv[1]+".json")
write_json(destination, report)
print(json.dumps({"report": str(destination), "wall_s": result["wall_s"],
                  "peak_mib": result["gpu_peak_mib"]}), flush=True)
raise SystemExit(result["exit_code"])
