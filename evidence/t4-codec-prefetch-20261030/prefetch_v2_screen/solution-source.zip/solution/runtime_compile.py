"""Overlap cold CPU kernel compilation with model loading in this measured PID.

Uses only JITFunction.warmup with dtype mock tensors. No GPU kernels, prebuilt
caches, task changes or external background process. Workers join before forward.
"""

from concurrent.futures import ThreadPoolExecutor
from functools import wraps

_pending = None
_started = False


def _jobs():
    import torch
    from triton.runtime.jit import MockTensor

    from ._activation_kernels import (
        activation_pack4_kernel,
        activation_pack_kernel,
        activation_unpack4_kernel,
        activation_unpack_kernel,
    )
    from ._ce_kernels import ce_backward_kernel, ce_merge_kernel, ce_partition_kernel
    from ._rmsnorm_kernels import rmsnorm_backward_kernel, rmsnorm_forward_kernel
    from .dtype_cast import _kernel
    from .swiglu import example_swiglu_bwd_kernel, example_swiglu_fwd_kernel

    f = MockTensor(torch.float32)
    h = MockTensor(torch.float16)
    i = MockTensor(torch.int8)
    u = MockTensor(torch.uint8)
    index = MockTensor(torch.int32)
    label = MockTensor(torch.int64)
    boolean = MockTensor(torch.bool)
    v, n = 151936, 512
    jobs = []

    def add(kernel, args, **kwargs):
        jobs.append((kernel, args, dict(grid=(1,), num_warps=4, **kwargs)))

    add(activation_pack_kernel, (f, i, f, 512), block=256)
    add(activation_unpack_kernel, (i, f, f, 512), block=256)
    add(activation_pack4_kernel, (h, u, f, 512), block=64)
    add(activation_unpack4_kernel, (u, f, h, 512), block=64)
    add(rmsnorm_forward_kernel, (f, f, f, f, 1536, 1e-6, 2048), enable_fp_fusion=False)
    add(rmsnorm_backward_kernel, (f, f, f, f, f, 1536, 2048), enable_fp_fusion=False)
    add(_kernel(), (f, h, 512), block=4096)
    add(_kernel(), (h, f, 512), block=4096)
    add(ce_partition_kernel, (h, f, f, f, index, n, v, n * v, v, 1, 38), block_size=4096)
    add(ce_merge_kernel, (h, label, f, f, f, index, f, f, f, boolean,
                          n, v, n * v, v, 1, n, 1, 38, -100, 0), merge_block=64)
    add(ce_backward_kernel, (h, label, f, f, h, n, v, n * v, v, 1, n, 1, 0, 0, -100, 0),
        block_size=4096)
    add(example_swiglu_fwd_kernel, (h, h, h, 8960), BLOCK=1024)
    add(example_swiglu_bwd_kernel, (h, h, h, h, h, 8960), BLOCK=1024)
    return jobs


def _compile(job):
    import torch

    kernel, args, kwargs = job
    with torch.cuda.device(0):
        kernel.warmup(*args, **kwargs)


def finish_runtime_compile():
    global _pending
    pending, _pending = _pending, None
    if pending is None:
        return
    executor, futures = pending
    failures = []
    try:
        for future in futures:
            try:
                future.result()
            except Exception as error:
                failures.append(type(error).__name__)
    finally:
        executor.shutdown(wait=True)
    if failures:
        from rich.console import Console

        Console().print({"runtime_compile_fallback": failures})


def start_runtime_compile():
    import torch

    global _pending, _started
    if _started or _pending is not None or not torch.cuda.is_available():
        return False
    try:
        from transformers.models.qwen2.modeling_qwen2 import Qwen2Model
    except (ImportError, AttributeError):
        return False
    original = Qwen2Model.forward
    if not getattr(original, "_setww_runtime_compile", False):
        @wraps(original)
        def forward(self, *args, **kwargs):
            finish_runtime_compile()
            return original(self, *args, **kwargs)

        forward._setww_runtime_compile = True
        Qwen2Model.forward = forward
    jobs = _jobs()
    executor = ThreadPoolExecutor(max_workers=4, thread_name_prefix="setww-cold-compile")
    _started = True
    _pending = (executor, [executor.submit(_compile, job) for job in jobs])
    return True
