"""Cross-stream and repeated-use parity for pipelined packet transfers."""

import pytest
import torch


@pytest.mark.skipif(not torch.cuda.is_available(), reason="CUDA required")
@pytest.mark.parametrize("bits", [4, 8])
def test_pipelined_values_streams_and_repeated_read(bits):
    import gc

    from solution.activation_storage import (
        pack_activation,
        saved_activation_hooks,
        unpack_activation,
    )
    from solution.pipelined_offload import _layer, offload_packed_hooks

    source = torch.randn(512, 1024, device="cuda", requires_grad=True) * 1
    expected = unpack_activation(pack_activation(source, bits=bits))
    pack, unpack = saved_activation_hooks(bits=bits)
    pack, unpack = offload_packed_hooks(pack, unpack)
    token = _layer.set(0)
    try:
        packet = pack(source)
        assert pack(source) is packet
        assert packet.packet.packed.is_pinned()
    finally:
        _layer.reset(token)
    consumer = torch.cuda.Stream()
    with torch.cuda.stream(consumer):
        actual = unpack(packet)
    torch.cuda.current_stream().wait_stream(consumer)
    torch.testing.assert_close(actual, expected, rtol=0, atol=0)
    del actual
    gc.collect()
    actual = unpack(packet)
    torch.testing.assert_close(actual, expected, rtol=0, atol=0)


@pytest.mark.skipif(not torch.cuda.is_available(), reason="CUDA required")
def test_many_packets_reverse_order_after_bounded_transfers():
    from solution.activation_storage import (
        pack_activation,
        saved_activation_hooks,
        unpack_activation,
    )
    from solution.pipelined_offload import _layer, offload_packed_hooks

    pack, unpack = saved_activation_hooks(bits=4, block=64)
    pack, unpack = offload_packed_hooks(pack, unpack)
    packets, expected = [], []
    token = _layer.set(0)
    try:
        for _ in range(17):
            source = torch.randn(128, 8960, device="cuda", requires_grad=True) * 1
            expected.append(unpack_activation(pack_activation(source, bits=4, block=64)))
            packets.append(pack(source))
    finally:
        _layer.reset(token)
    consumer = torch.cuda.Stream()
    with torch.cuda.stream(consumer):
        restored = [unpack(packet) for packet in reversed(packets)]
    torch.cuda.current_stream().wait_stream(consumer)
    for actual, reference in zip(restored, reversed(expected), strict=True):
        torch.testing.assert_close(actual, reference, rtol=0, atol=0)
