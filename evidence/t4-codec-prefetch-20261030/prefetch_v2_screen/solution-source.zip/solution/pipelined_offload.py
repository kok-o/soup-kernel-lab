"""Measured-process asynchronous quantized-packet offload with backward prefetch."""

import weakref
from collections import deque
from contextvars import ContextVar
from functools import wraps

_layer = ContextVar("setww_offload_layer", default=None)
_streams = {}


class _Transfer:
    def __init__(self, packet, device, ready, index):
        self.packet, self.device, self.ready, self.index = packet, device, ready, index
        self.gpu_packed = self.gpu_scales = self.loaded = None
        self.consumed = False


def _copy_stream(device):
    import torch

    key = device.index
    if key not in _streams:
        _streams[key] = torch.cuda.Stream(device=device)
    return _streams[key]


def offload_packed_hooks(pack, unpack, *, min_bytes=262144):
    import torch

    from .activation_storage import _Packet

    records, wrappers = [], {}
    pending = deque()
    started = False

    def prefetch(value, required=False):
        if value.gpu_packed is not None or value.consumed and not required:
            return
        stream = _copy_stream(value.device)
        with torch.cuda.device(value.device), torch.cuda.stream(stream):
            stream.wait_event(value.ready)
            value.gpu_packed = value.packet.packed.to(value.device, non_blocking=True)
            value.gpu_scales = value.packet.scales.to(value.device, non_blocking=True)
            value.loaded = torch.cuda.Event()
            value.loaded.record(stream)

    def offload(tensor):
        packet = pack(tensor)
        if not isinstance(packet, _Packet):
            return packet
        previous = wrappers.get(id(packet))
        previous = previous() if previous is not None else None
        if previous is not None:
            return previous
        layer = _layer.get()
        if (layer is None or layer >= 28
                or packet.packed.numel() * packet.packed.element_size() < min_bytes):
            return packet
        device = packet.packed.device
        stream = _copy_stream(device)
        with torch.cuda.device(device):
            producer = torch.cuda.Event()
            producer.record(torch.cuda.current_stream(device))
            host_packed = torch.empty_like(packet.packed, device="cpu", pin_memory=True)
            host_scales = torch.empty_like(packet.scales, device="cpu", pin_memory=True)
            with torch.cuda.stream(stream):
                stream.wait_event(producer)
                host_packed.copy_(packet.packed, non_blocking=True)
                host_scales.copy_(packet.scales, non_blocking=True)
                packet.packed.record_stream(stream)
                packet.scales.record_stream(stream)
                ready = torch.cuda.Event()
                ready.record(stream)
        pending.append(ready)
        if len(pending) > 8:
            pending.popleft().synchronize()
        packet.packed, packet.scales = host_packed, host_scales
        result = _Transfer(packet, device, ready, len(records))
        records.append(result)
        wrappers[id(packet)] = weakref.ref(result)
        return result

    def restore(value):
        nonlocal started
        if not started:
            started = True
            for item in records[-2:]:
                prefetch(item)
        if not isinstance(value, _Transfer):
            return unpack(value)
        packet = value.packet
        cached = packet.decoded() if packet.decoded is not None else None
        if cached is not None:
            return unpack(packet)
        prefetch(value, required=True)
        for item in records[max(0, value.index - 2):value.index]:
            prefetch(item)
        host_packed, host_scales = packet.packed, packet.scales
        with torch.cuda.device(value.device):
            current = torch.cuda.current_stream(value.device)
            current.wait_event(value.loaded)
            packet.packed, packet.scales = value.gpu_packed, value.gpu_scales
            packet.packed.record_stream(current)
            packet.scales.record_stream(current)
            try:
                return unpack(packet)
            finally:
                packet.packed, packet.scales = host_packed, host_scales
                value.gpu_packed = value.gpu_scales = None
                value.consumed = True

    return offload, restore


def patch_offload_layers():
    try:
        from transformers.models.qwen2.modeling_qwen2 import Qwen2DecoderLayer
    except (ImportError, AttributeError):
        return False
    original = Qwen2DecoderLayer.forward
    if getattr(original, "_setww_offload_layer", False):
        return True

    @wraps(original)
    def forward(self, *args, **kwargs):
        token = _layer.set(self.self_attn.layer_idx)
        try:
            return original(self, *args, **kwargs)
        finally:
            _layer.reset(token)

    forward._setww_offload_layer = True
    Qwen2DecoderLayer.forward = forward
    return True
