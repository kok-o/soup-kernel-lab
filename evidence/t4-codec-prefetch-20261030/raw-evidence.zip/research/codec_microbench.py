
import json
from pathlib import Path

def main():
    import torch
    import triton
    from triton.testing import do_bench
    from research import codec_reference as old
    from solution import _activation_kernels as new
    rows=[]
    for bits,block,elements,dtype in ((4,64,831*8960,torch.float16),
                                    (8,256,4*512*1536,torch.float32)):
        x=torch.randn(elements,device="cuda",dtype=dtype)
        p=torch.empty((elements+1)//2 if bits==4 else elements,device="cuda",
                      dtype=torch.uint8 if bits==4 else torch.int8)
        s=torch.empty(triton.cdiv(elements,block),device="cuda",dtype=torch.float32)
        y=torch.empty_like(x)
        for kind,args in (("pack",(x,p,s,elements)),("unpack",(p,s,y,elements))):
            name="activation_"+kind+("4" if bits==4 else "")+"_kernel"
            functions=(("reserve",getattr(old,name),s.numel()),
                       ("grouped",getattr(new,name),(s.numel()+15)//16))
            for label,fn,grid in functions:
                launch=lambda:fn[(grid,)](*args,block=block,num_warps=4)
                launch()
                rows.append({"bits":bits,"kind":kind,"variant":label,
                             "median_ms":do_bench(launch,warmup=50,rep=150,return_mode="median")})
    Path("codec_microbench.json").write_text(json.dumps(rows,indent=2))

if __name__=="__main__":
    main()
