"""Byte parity with the qualified codec, including incomplete CTAs and zero blocks."""

import pytest


@pytest.mark.parametrize("bits,block", [(4, 64), (4, 256), (8, 256)])
@pytest.mark.parametrize("dtype_name", ["float16", "float32"])
@pytest.mark.parametrize("elements", [31, 26897, 7445760])
def test_codec_matches_reserve(bits, block, dtype_name, elements):
    import torch
    import triton

    from research import codec_reference
    from solution.activation_storage import pack_activation, unpack_activation

    if not torch.cuda.is_available():
        pytest.skip("CUDA required")
    source = torch.randn(elements, device="cuda", dtype=getattr(torch, dtype_name))
    source[:block] = 0
    packet = pack_activation(source, bits=bits, block=block)
    packed = torch.empty_like(packet.packed)
    scales = torch.empty_like(packet.scales)
    old_pack = (codec_reference.activation_pack4_kernel if bits == 4
                else codec_reference.activation_pack_kernel)
    old_unpack = (codec_reference.activation_unpack4_kernel if bits == 4
                  else codec_reference.activation_unpack_kernel)
    old_pack[(triton.cdiv(elements, block),)](
        source, packed, scales, elements, block=block, num_warps=4,
    )
    assert torch.equal(packet.packed, packed)
    assert torch.equal(packet.scales, scales)
    previous = torch.empty_like(source)
    old_unpack[(scales.numel(),)](
        packed, scales, previous, elements, block=block, num_warps=4,
    )
    assert torch.equal(unpack_activation(packet), previous)
