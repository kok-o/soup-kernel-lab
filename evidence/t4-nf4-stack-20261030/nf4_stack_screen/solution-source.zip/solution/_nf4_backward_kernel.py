"""Original NF4/nested-scale decoding for the frozen projection backward."""
# ruff: noqa: N803 -- preserve PR14 Triton constexpr names and call contract.

import triton
import triton.language as tl


@triton.jit(do_not_specialize=["elements"])
def nf4_backward_dequant_kernel(
    packed,
    scales,
    codebook,
    nested_absmax,
    nested_code,
    offset,
    destination,
    elements,
    NESTED: tl.constexpr,
    QUANT_BLOCK: tl.constexpr,
    SCALE_BLOCK: tl.constexpr,
    BLOCK: tl.constexpr,
):
    index = tl.program_id(0) * BLOCK + tl.arange(0, BLOCK)
    valid = index < elements
    byte = tl.load(packed + index // 2, valid, other=0).to(tl.int32)
    code = tl.where(index % 2 == 0, byte >> 4, byte & 15)
    value = tl.load(codebook + code).to(tl.float32)
    group = index // QUANT_BLOCK
    if NESTED:
        scale_code = tl.load(scales + group, valid, other=0).to(tl.int32)
        level = tl.load(nested_code + scale_code).to(tl.float32)
        amplitude = tl.load(nested_absmax + group // SCALE_BLOCK, valid, other=0).to(tl.float32)
        scale = level * amplitude
        scale = scale + tl.load(offset).to(tl.float32)
    else:
        scale = tl.load(scales + group, valid, other=0).to(tl.float32)
    tl.store(destination + index, value * scale, valid)
