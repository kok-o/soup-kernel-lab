"""Exact NF4 backward decoder and unchanged real Linear4bit forward/gradients."""

import pytest


@pytest.fixture(autouse=True)
def cuda_required():
    import torch

    if not torch.cuda.is_available():
        pytest.skip("CUDA/bnb required")


@pytest.mark.parametrize("nested", [False, True])
@pytest.mark.parametrize("shape", [(256, 128), (1536, 1536), (8960, 1536)])
def test_nf4_decode_is_exact(shape, nested):
    import bitsandbytes.functional as functional
    import torch

    from solution.nf4_backward import decode_nf4

    torch.manual_seed(719)
    packed, state = functional.quantize_4bit(
        torch.randn(shape, device="cuda", dtype=torch.float16),
        blocksize=64,
        compress_statistics=nested,
        quant_type="nf4",
    )
    expected = functional.dequantize_4bit(packed, state)
    actual = decode_nf4(packed, state)
    torch.cuda.synchronize()
    assert torch.equal(actual, expected)


@pytest.mark.parametrize(
    "width,outputs,bias", [(128, 256, True), (1536, 1536, True), (1536, 8960, False)]
)
def test_actual_linear_forward_and_scaled_input_gradient(monkeypatch, width, outputs, bias):
    import bitsandbytes as bnb
    import torch

    from solution.nf4_backward import patch_nf4_backward

    original = bnb.nn.Linear4bit.forward
    while any(
        getattr(original, flag, False) for flag in ("_setww_nf4_backward", "_setww_training_casts")
    ):
        original = original.__wrapped__
    monkeypatch.setattr(bnb.nn.Linear4bit, "forward", original)
    torch.manual_seed(413)
    layer = (
        bnb.nn.Linear4bit(
            width,
            outputs,
            bias=bias,
            compute_dtype=torch.float16,
            compress_statistics=True,
            quant_type="nf4",
        )
        .half()
        .cuda()
        .train()
    )
    layer.weight.requires_grad_(False)
    if layer.bias is not None:
        layer.bias.requires_grad_(False)
    assert layer.weight.quant_state.dtype == torch.float16
    x = torch.randn(2, 19, width, device="cuda", requires_grad=True)
    incoming = torch.randn(2, 19, outputs, device="cuda") * 128
    with torch.autocast("cuda", dtype=torch.float16):
        expected = layer(x)
    (expected_dx,) = torch.autograd.grad(expected, x, incoming)
    assert patch_nf4_backward()
    fn = bnb.nn.Linear4bit.forward
    assert patch_nf4_backward() and bnb.nn.Linear4bit.forward is fn
    with torch.autocast("cuda", dtype=torch.float16):
        actual = layer(x)
    (actual_dx,) = torch.autograd.grad(actual, x, incoming)
    torch.cuda.synchronize()
    assert actual.grad_fn.__class__.__name__ == "_NF4BackwardBackward"
    assert torch.equal(actual, expected)
    assert torch.equal(actual_dx, expected_dx)
