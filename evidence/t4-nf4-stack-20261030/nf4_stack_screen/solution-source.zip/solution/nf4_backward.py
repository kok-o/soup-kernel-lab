"""Keep genuine bnb forward, decode NF4 with our kernel only in backward.

Original implementation by @Nari-Ab in team PR14; integrated without math changes.

Canonical NF4 and double-quant state stay unchanged. No persistent dense-weight
cache is allocated. Decode arithmetic follows the installed QuantState format;
kernel source is original, not copied from bitsandbytes.
"""

from functools import lru_cache, wraps


def decode_nf4(packed, state):
    import torch
    import triton

    from ._nf4_backward_kernel import nf4_backward_dequant_kernel

    if (
        not packed.is_cuda
        or state.dtype != torch.float16
        or state.quant_type != "nf4"
        or state.blocksize != 64
    ):
        raise ValueError("decoder requires CUDA NF4/FP16 with block64")
    output = torch.empty(state.shape, device=packed.device, dtype=state.dtype)
    nested = state.nested
    second = state.state2 if nested else None
    with torch.cuda.device(packed.device):
        nf4_backward_dequant_kernel[(triton.cdiv(output.numel(), 1024),)](
            packed,
            state.absmax,
            state.code,
            second.absmax if nested else state.absmax,
            second.code if nested else state.code,
            state.offset if nested else state.absmax,
            output,
            output.numel(),
            NESTED=nested,
            QUANT_BLOCK=64,
            SCALE_BLOCK=second.blocksize if nested else 256,
            BLOCK=1024,
            num_warps=4,
            enable_fp_fusion=False,
        )
    return output


@lru_cache(maxsize=1)
def _autograd():
    import torch
    from torch.autograd.function import once_differentiable

    from .dtype_cast import _convert

    class _NF4Backward(torch.autograd.Function):
        @staticmethod
        def forward(ctx, x, weight, bias, module, original):
            output = original(module, x)
            state = weight.quant_state
            tensors = [weight, state.absmax, state.code]
            if state.nested:
                tensors.extend((state.state2.absmax, state.state2.code, state.offset))
            ctx.save_for_backward(*tensors)
            ctx.state, ctx.input_dtype = state, x.dtype
            return output

        @staticmethod
        @once_differentiable
        def backward(ctx, incoming):
            if not ctx.needs_input_grad[0]:
                return (None,) * 5
            weight, *_versions = ctx.saved_tensors
            # Preserve the original output-cast backward BEFORE the FP16 GEMM.
            compute_gradient = _convert(incoming, torch.float16)
            decoded = decode_nf4(weight, ctx.state)
            gradient = torch.matmul(compute_gradient, decoded)
            return _convert(gradient, ctx.input_dtype), None, None, None, None

    return _NF4Backward


def patch_nf4_backward():
    import torch

    try:
        from bitsandbytes.nn import Linear4bit
    except (ImportError, AttributeError):
        return False
    original = Linear4bit.forward
    if getattr(original, "_setww_nf4_backward", False):
        return True

    @wraps(original)
    def forward(self, x):
        weight = self.weight
        state = getattr(weight, "quant_state", None)
        supported = (
            self.training
            and torch.is_grad_enabled()
            and x.is_cuda
            and x.dtype in (torch.float16, torch.float32)
            and x.is_contiguous()
            and x.numel() > 0
            and not weight.requires_grad
            and weight.is_cuda
            and weight.dtype == torch.uint8
            and weight.is_contiguous()
            and state is not None
            and state.dtype == torch.float16
            and state.quant_type == "nf4"
            and state.blocksize == 64
            and len(state.shape) == 2
            and state.shape[-1] == x.shape[-1]
            and self.compute_dtype == torch.float16
            and self.compute_type_is_set
            and (self.bias is None or not self.bias.requires_grad)
        )
        if not supported:
            return original(self, x)
        return _autograd().apply(x, weight, self.bias, self, original)

    forward._setww_nf4_backward = True
    Linear4bit.forward = forward
    return True
