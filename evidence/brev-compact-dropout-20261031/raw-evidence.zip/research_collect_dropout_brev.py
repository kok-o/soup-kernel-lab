"""Source-bound original full cold train/eval evidence for both Brev variants."""

import datetime
import hashlib
import io
import json
import zipfile
from pathlib import Path

lab = Path("/home/ubuntu/workspace/soup-lab")
members = {}
cases = []
for directory, prefix, commit, run, launch_log in (
    ("compact-dropout", "runs_brev_dropout10", "35ea24c796a35a93e8beca5943675fc4fae70d16",
     "runs_dropout_screen", "dropout-screen.log"),
    ("compact-dropout14", "runs_brev_dropout14", "c7ccd89064e042af74ae09432a192aa574e6be09",
     "runs_dropout14_screen", "dropout14-screen.log"),
):
    repo = lab / directory
    result_bytes = (repo / run / "result.json").read_bytes()
    result = json.loads(result_bytes)
    assert result["summary"]["solution"]["ok"]
    digest = hashlib.sha256()
    source_bytes = io.BytesIO()
    with zipfile.ZipFile(source_bytes, "w", zipfile.ZIP_DEFLATED) as archive:
        for path in sorted((repo / "solution").glob("*.py")):
            data = path.read_bytes()
            digest.update(path.name.encode())
            digest.update(data)
            archive.writestr("solution/"+path.name, data)
    provenance = {"code_commit": commit, "solution_sha256": digest.hexdigest(),
        "result_sha256": hashlib.sha256(result_bytes).hexdigest(),
        "platform": "Brev dedicated Tesla T4", "official_kaggle_qualification": False,
        "measurement": "unchanged official run_task.py --only solution; full cold train timed from parent; eval separate; new compiler caches"}
    members[prefix+"/PROVENANCE.json"] = json.dumps(provenance, indent=2).encode()
    members[prefix+"/result.json"] = result_bytes
    members[prefix+"/solution-source.zip"] = source_bytes.getvalue()
    for relative in ("solution_1/train.log", "solution_1/metrics.json", "solution_1/task.yaml",
                     "eval_solution.json", "eval_solution.log"):
        path = repo / run / relative
        assert path.is_file(), str(path)
        members[prefix+"/"+relative] = path.read_bytes()
    for name in ("full-tests.log", "dropout-tests.log", launch_log):
        path = repo / name
        if path.is_file():
            members[prefix+"/"+name] = path.read_bytes()
    assert b"302 passed" in (repo / "full-tests.log").read_bytes()
    cases.append({"case": prefix, "source": provenance,
                  "summary": result["summary"]["solution"]})
members["SUMMARY.json"] = json.dumps({"platform": "Brev, not Kaggle",
    "created_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "cases": cases}, indent=2).encode()
members["research_collect_dropout_brev.py"] = Path(__file__).read_bytes()
manifest = {name: hashlib.sha256(data).hexdigest() for name, data in sorted(members.items())}
members["EVIDENCE_MANIFEST.json"] = json.dumps(manifest, indent=2).encode()
destination = lab / "dropout-brev-cold-evidence.zip"
with zipfile.ZipFile(destination, "w", zipfile.ZIP_DEFLATED) as archive:
    for name, data in sorted(members.items()):
        archive.writestr(name, data)
print(json.dumps({"archive": str(destination), "sha256": hashlib.sha256(
    destination.read_bytes()).hexdigest(), "cases": cases}, indent=2), flush=True)
