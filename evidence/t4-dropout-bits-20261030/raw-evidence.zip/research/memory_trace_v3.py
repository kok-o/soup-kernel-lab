"""Diagnostic wrapper of the unchanged trainer: allocations by training phase."""

import json
import os
import runpy
from functools import wraps
from pathlib import Path


def main():
    import solution

    repo = Path(__file__).absolute().parents[1]
    records = []
    step = [0]
    original_apply = solution.apply

    def traced_apply():
        import torch
        from transformers import Trainer, TrainerCallback
        from transformers.models.qwen2.modeling_qwen2 import Qwen2DecoderLayer, Qwen2Model

        original_apply()
        from solution import forward_head, frozen_storage

        def record(phase, layer=None):
            records.append({
                "step": step[0], "phase": phase, "layer": layer,
                "allocated_mib": torch.cuda.memory_allocated() / 2**20,
                "reserved_mib": torch.cuda.memory_reserved() / 2**20,
                "peak_allocated_mib": torch.cuda.max_memory_allocated() / 2**20,
            })

        class MemoryCallback(TrainerCallback):
            def on_train_begin(self, args, state, control, **kwargs):
                record("train_begin")

            def on_step_begin(self, args, state, control, **kwargs):
                step[0] = state.global_step
                record("step_begin")

            def on_step_end(self, args, state, control, **kwargs):
                record("step_end")

        trainer_init = Trainer.__init__

        @wraps(trainer_init)
        def initialize(self, *args, **kwargs):
            trainer_init(self, *args, **kwargs)
            self.add_callback(MemoryCallback())
            record("trainer_ready")

        Trainer.__init__ = initialize
        model_forward = Qwen2Model.forward

        @wraps(model_forward)
        def decoder(self, *args, **kwargs):
            record("decoder_begin")
            result = model_forward(self, *args, **kwargs)
            record("decoder_end")
            return result

        Qwen2Model.forward = decoder
        layer_forward = Qwen2DecoderLayer.forward

        @wraps(layer_forward)
        def layer(self, *args, **kwargs):
            index = self.self_attn.layer_idx
            if index in (0, 13, 27):
                record("layer_begin", index)
            result = layer_forward(self, *args, **kwargs)
            if index in (0, 13, 27):
                record("layer_end", index)
            return result

        Qwen2DecoderLayer.forward = layer
        head_forward = forward_head.forward_head_terms

        @wraps(head_forward)
        def head(*args, **kwargs):
            record("head_begin")
            result = head_forward(*args, **kwargs)
            record("head_end")
            return result

        forward_head.forward_head_terms = head
        compact_original = frozen_storage.compact_frozen_tied_embedding

        @wraps(compact_original)
        def compact(model):
            record("compact_begin")
            result = compact_original(model)
            record("compact_end")
            return result

        frozen_storage.compact_frozen_tied_embedding = compact

    solution.apply = traced_apply
    try:
        runpy.run_path(str(repo / "harness/_train.py"), run_name="__main__")
    finally:
        Path(os.environ["SETWW_MEMORY_REPORT"]).write_text(json.dumps({
            "diagnostic_only": True,
            "source_commit": "80a91752b50d6b1e56eb4b5ab999a2d0b5a6318f",
            "snapshots": records,
        }, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
