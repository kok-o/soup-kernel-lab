"""Diagnostic only: stop the unchanged task immediately after real PEFT preparation."""

import json
import os
import runpy
import sys
import time
from pathlib import Path


def main():
    import solution

    original_apply = solution.apply
    report_path = Path(os.environ["SETWW_PREPARATION_REPORT"])
    mode = os.environ["SETWW_PREPARATION_MODE"]

    def traced_apply():
        original_apply()
        import torch
        from peft.utils import other

        retained = other.prepare_model_for_kbit_training
        native = retained
        while getattr(native, "_setww_early_frozen_storage", False):
            native = native.__wrapped__
        assert native is not retained

        def observed(model, *args, **kwargs):
            weight = model.get_input_embeddings().weight
            pointer = weight.data_ptr()
            before_dtype = str(weight.dtype)
            torch.cuda.synchronize()
            before = torch.cuda.memory_allocated()
            previous_peak = torch.cuda.max_memory_allocated()
            torch.cuda.reset_peak_memory_stats()
            started = time.perf_counter()
            target = retained if mode == "retained_half" else native
            result = target(model, *args, **kwargs)
            torch.cuda.synchronize()
            prepared_weight = result.get_input_embeddings().weight
            report = {
                "diagnostic_only": True, "mode": mode,
                "preparation_s": time.perf_counter()-started,
                "before_allocated_mib": before/2**20,
                "previous_peak_mib": previous_peak/2**20,
                "preparation_peak_mib": torch.cuda.max_memory_allocated()/2**20,
                "after_allocated_mib": torch.cuda.memory_allocated()/2**20,
                "matrix_numel": weight.numel(), "before_dtype": before_dtype,
                "after_dtype": str(prepared_weight.dtype),
                "retained_hook_active": getattr(result, "_setww_retained_frozen_half", False),
                "storage_pointer_unchanged": prepared_weight.data_ptr() == pointer,
                "tied_after": result.get_output_embeddings().weight is prepared_weight,
                "embedding_output_hook": bool(getattr(
                    result.get_input_embeddings(), "_setww_compact_frozen_storage", False)),
                "other_parameter_dtypes": sorted({str(parameter.dtype)
                    for parameter in result.parameters() if parameter is not prepared_weight}),
            }
            report_path.write_text(json.dumps(report, indent=2), encoding="utf-8")
            # Stop before constructing a trainer; this is not a scored training run.
            raise SystemExit(0)

        for name, module in list(sys.modules.items()):
            if (module is not None and name.split(".")[0] in ("peft", "soup_cli", "trl")
                    and module.__dict__.get("prepare_model_for_kbit_training") is retained):
                module.prepare_model_for_kbit_training = observed

    solution.apply = traced_apply
    repo = Path(__file__).absolute().parent.parent
    runpy.run_path(str(repo / "harness/_train.py"), run_name="__main__")


if __name__ == "__main__":
    main()
