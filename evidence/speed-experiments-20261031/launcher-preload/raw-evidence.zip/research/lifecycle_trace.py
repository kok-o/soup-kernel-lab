"""Diagnostic only: unchanged official profiler plus actual bnb shape/path counts."""

import hashlib
import json
import os
import runpy
import time
from collections import Counter
from functools import wraps
from pathlib import Path


def main():
    import solution

    repo = Path(__file__).absolute().parent
    if repo.name == "research":
        repo = repo.parent
    started = time.perf_counter()
    phases = []
    dispatches = Counter()
    slow_jit = []
    original_apply = solution.apply

    def mark(name, **extra):
        phases.append({"phase": name, "elapsed_s": round(time.perf_counter()-started, 5),
                       **extra})

    def traced_apply():
        mark("apply_begin")
        original_apply()
        mark("apply_end")
        import bitsandbytes.backends.cuda.ops as operations
        from transformers import PreTrainedModel, Trainer, TrainerCallback

        from solution import runtime_compile
        from triton.runtime.jit import JITFunction

        previous_run = JITFunction.run

        def timed_jit(kernel, *args, **kwargs):
            before = time.perf_counter()
            result = previous_run(kernel, *args, **kwargs)
            duration = time.perf_counter() - before
            if not kwargs.get("warmup") and duration > 0.03:
                slow_jit.append({"name": kernel.fn.__name__, "elapsed_s": duration,
                    "arguments": [str(value.dtype) if hasattr(value, "dtype") else value
                                  for value in args],
                    "launch": {key: value for key, value in kwargs.items()
                               if isinstance(value, (str, int, float, bool))}})
            return result

        JITFunction.run = timed_jit

        for name in ("_gemm_4bit_kernel_impl", "_dequant_linear_fallback"):
            original = getattr(operations, name)

            def observed(*args, _original=original, _name=name, **kwargs):
                source, _, shape = args[:3]
                dispatches[(_name, source.numel() // source.shape[-1],
                            int(shape[0]), int(shape[1]), str(source.dtype))] += 1
                return _original(*args, **kwargs)

            setattr(operations, name, observed)

        loader = PreTrainedModel.from_pretrained.__func__

        @classmethod
        @wraps(loader)
        def load(cls, *args, **kwargs):
            mark("model_load_begin")
            result = loader(cls, *args, **kwargs)
            mark("model_load_end")
            return result

        PreTrainedModel.from_pretrained = load
        original_init = Trainer.__init__

        @wraps(original_init)
        def initialize(self, *args, **kwargs):
            mark("trainer_init_begin")
            original_init(self, *args, **kwargs)
            mark("trainer_init_end")
            self.add_callback(Phases())

        class Phases(TrainerCallback):
            def on_train_begin(self, args, state, control, **kwargs):
                mark("train_begin")

            def on_step_begin(self, args, state, control, **kwargs):
                if state.global_step < 2:
                    mark("step_begin", step=state.global_step)

            def on_step_end(self, args, state, control, **kwargs):
                if state.global_step <= 2:
                    mark("step_end", step=state.global_step)

            def on_train_end(self, args, state, control, **kwargs):
                mark("train_end")

        Trainer.__init__ = initialize
        trainer_save = Trainer.save_model

        @wraps(trainer_save)
        def save_model(self, *args, **kwargs):
            mark("save_model_begin")
            result = trainer_save(self, *args, **kwargs)
            mark("save_model_end")
            return result

        Trainer.save_model = save_model
        from peft import PeftModel

        adapter_save = PeftModel.save_pretrained

        @wraps(adapter_save)
        def save_adapter(self, *args, **kwargs):
            mark("save_adapter_begin")
            result = adapter_save(self, *args, **kwargs)
            mark("save_adapter_end")
            return result

        PeftModel.save_pretrained = save_adapter
        finish = runtime_compile.finish_runtime_compile
        first = [True]

        @wraps(finish)
        def finish_compiling():
            if not first[0]:
                return finish()
            first[0] = False
            mark("jit_join_begin")
            finish()
            mark("jit_join_end")

        runtime_compile.finish_runtime_compile = finish_compiling

    solution.apply = traced_apply
    try:
        runpy.run_path(str(repo / "harness/_train.py"), run_name="__main__")
    finally:
        mark("process_end")
        digest = hashlib.sha256()
        for path in sorted((repo / "solution").glob("*.py")):
            digest.update(path.name.encode())
            digest.update(path.read_bytes())
        report = {"diagnostic_only": True, "solution_sha256": digest.hexdigest(),
                  "slow_jit_calls": slow_jit,
                  "phases": phases, "dispatches": [
                      {"path": key[0], "M": key[1], "N": key[2], "K": key[3],
                       "dtype": key[4], "calls": count}
                      for key, count in sorted(dispatches.items())]}
        Path(os.environ["SETWW_SPEED_PROFILE_REPORT"]).write_text(
            json.dumps(report, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
