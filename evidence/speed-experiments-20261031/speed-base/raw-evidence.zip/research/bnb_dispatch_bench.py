"""Installed bnb dispatch versus forced SM75 GEMM, fallback and dense control.

Microbench only: this does not modify training code or claim full-command gains.
"""

import hashlib
import json
import os
from collections import Counter
from pathlib import Path


def main():
    import bitsandbytes as bnb
    import bitsandbytes.backends.cuda.ops as operations
    import bitsandbytes.functional as functional
    import torch
    from rich.console import Console

    console = Console()
    assert torch.cuda.get_device_capability() == (7, 5)
    torch.manual_seed(72913)
    profile = json.loads(Path(os.environ["SETWW_SPEED_PROFILE_REPORT"]).read_text())
    frequencies = Counter()
    for entry in profile["dispatches"]:
        if (entry["N"], entry["K"]) in ((8960, 1536), (1536, 8960)):
            frequencies[entry["M"]] += entry["calls"]
    rows = sorted({64, 128, 256, 512, 1024, 1536, 2048,
                   *(value for value, _ in frequencies.most_common(4))})
    results = []
    kernel_names = {}
    for outputs, inputs in ((8960, 1536), (1536, 8960), (1536, 1536), (256, 1536)):
        weights = torch.randn(outputs, inputs, device="cuda", dtype=torch.float16) * 0.02
        packed, state = functional.quantize_4bit(weights, blocksize=64,
            compress_statistics=True, quant_type="nf4")
        del weights
        decoded = functional.dequantize_4bit(packed, state)
        extra = {"absmax_8bit": state.absmax, "absmax_code": state.state2.code,
                 "absmax_offset": state.offset}
        arguments = (packed, state.shape, state.state2.absmax, 64, "nf4")
        for count in rows:
            source = torch.randn(count, inputs, device="cuda", dtype=torch.float16) * 0.1
            choices = {
                "default": lambda: torch.ops.bitsandbytes.gemm_4bit.default(
                    source, *arguments, **extra),
                "forced_fused": lambda: operations._gemm_4bit_kernel_impl(
                    source, *arguments, **extra),
                "decode_cublas": lambda: operations._dequant_linear_fallback(
                    source, *arguments, **extra),
                "dense_control": lambda: torch.nn.functional.linear(source, decoded),
            }
            with torch.no_grad():
                expected = choices["decode_cublas"]()
                for name, function in choices.items():
                    try:
                        actual = function()
                        delta = actual.float() - expected.float()
                        error = {"max_abs": delta.abs().max().item(),
                                 "relative_rms": (delta.square().mean().sqrt()
                                     / expected.float().square().mean().sqrt()).item(),
                                 "equal": torch.equal(actual, expected)}
                        for _ in range(8):
                            function()
                        start, end = (torch.cuda.Event(enable_timing=True) for _ in range(2))
                        start.record()
                        for _ in range(30):
                            function()
                        end.record()
                        end.synchronize()
                        milliseconds = start.elapsed_time(end) / 30
                        results.append({"M": count, "N": outputs, "K": inputs, "mode": name,
                                        "ms": milliseconds, **error})
                        if count == rows[len(rows)//2]:
                            with torch.profiler.profile(activities=[
                                torch.profiler.ProfilerActivity.CUDA]) as observed:
                                function()
                                torch.cuda.synchronize()
                            from torch.autograd import DeviceType

                            kernel_names[f"{outputs}x{inputs}:{name}"] = [
                                event.key for event in observed.key_averages()
                                if event.device_type == DeviceType.CUDA]
                    except RuntimeError as error:
                        results.append({"M": count, "N": outputs, "K": inputs,
                                        "mode": name, "error": str(error)[:500]})
            del source, expected
        del decoded, packed, state
    report = {"diagnostic_only": True, "bnb": bnb.__version__,
              "gpu": torch.cuda.get_device_name(), "capability": [7, 5],
              "installed_ops_sha256": hashlib.sha256(Path(operations.__file__).read_bytes())
                  .hexdigest(),
              "actual_mlp_rows": dict(frequencies), "rows": rows,
              "results": results, "kernel_names": kernel_names}
    Path(os.environ["SETWW_BNB_BENCH_REPORT"]).write_text(
        json.dumps(report, indent=2), encoding="utf-8")
    for outputs, inputs in ((8960, 1536), (1536, 8960), (1536, 1536), (256, 1536)):
        selected = [row for row in results if (row["N"], row["K"]) == (outputs, inputs)]
        for count in rows:
            modes = {row["mode"]: round(row["ms"], 5) for row in selected
                     if row["M"] == count and "ms" in row}
            console.print({"M": count, "N": outputs, "K": inputs, "milliseconds": modes})
    console.print({"saved": os.environ["SETWW_BNB_BENCH_REPORT"]})


if __name__ == "__main__":
    main()
